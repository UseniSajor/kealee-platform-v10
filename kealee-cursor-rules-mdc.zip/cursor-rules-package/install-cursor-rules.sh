#!/bin/bash
# Run from kealee-platform-v10 root
echo "Installing Kealee Cursor rules..."
mkdir -p .cursor/rules
cp .cursor-rules-source/*.mdc .cursor/rules/

# Remove legacy .cursorrules if present (causes conflicts)
if [ -f ".cursorrules" ]; then
  echo "Removing legacy .cursorrules (deprecated, ignored in Agent mode)"
  rm .cursorrules
fi

echo "Done. Rules installed:"
ls .cursor/rules/
echo ""
echo "Next: Restart Cursor completely to load rules."
echo "Verify: Open Chat → type /rules → all 6 rules should show as active."
