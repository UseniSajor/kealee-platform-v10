# KEALEE PLATFORM v30
## Automated Marketing + Sales Bot System (Complete Implementation)
### All-In-One Marketing Automation: Traffic, Leads, Conversions, Paid Transactions

---

# PART 1: SYSTEM ARCHITECTURE

## 11th Bot: MarketingBot
### Purpose: Automated platform traffic generation, lead acquisition, and sales optimization

```
MarketingBot (Claude Sonnet 4.6)
├─ Traffic Generation Engine
│  ├─ SEO optimization (Google, local)
│  ├─ Content strategy (blog, video, social)
│  ├─ Ad copy generation (Google Ads, Meta, LinkedIn)
│  └─ Landing page optimization
│
├─ Lead Generation Engine
│  ├─ Lead magnet creation
│  ├─ Email sequences (nurture + conversion)
│  ├─ Lead scoring + qualification
│  └─ Lead routing to sales team
│
├─ Sales Optimization Engine
│  ├─ Objection handling (SalesBot integration)
│  ├─ Pricing optimization (A/B testing)
│  ├─ Upsell/cross-sell recommendations
│  └─ Customer retention strategies
│
└─ Paid Transaction Maximization
   ├─ Checkout funnel optimization
   ├─ Payment failure recovery
   ├─ Subscription lifecycle management
   └─ Revenue analytics + insights
```

---

## Integration with Existing Systems

### Current Systems (Keep & Enhance)
```
✓ GoHighLevel (GHL) - Marketing automation, CRM, email
✓ Zoho CRM - Client data, pipeline tracking
✓ Stripe - Payment processing + webhooks
✓ Meta Graph API - Facebook/Instagram ads + organic
✓ BullMQ - Job queue system (16 queues, 15 workers)
✓ Resend - Email delivery
✓ OpenClaw - Agent system (Python, Windows/WSL2)
```

### New Integration Points
```
+ MarketingBot (Claude Sonnet) - AI-powered strategy
+ Klaviyo - Email marketing (premium, high ROI)
+ Segment - Customer data platform
+ Mixpanel - Analytics + behavioral tracking
+ HubSpot - Lead scoring + workflow automation
+ Google Analytics 4 - Traffic + conversion tracking
+ Airtable - Campaign management + tracking
+ Zapier - Workflow automation
```

---

## Marketing Automation Workflow

```
TRAFFIC GENERATION LAYER
│
├─ Organic (SEO, Social, Content)
│  ├─ Blog posts (2/week via ContentBot)
│  ├─ Social media posts (3/day via SocialBot)
│  ├─ YouTube videos (1/week via VideoBot)
│  └─ Local SEO optimization
│
├─ Paid (Google Ads, Meta, LinkedIn)
│  ├─ Search ads (intent: "kitchen remodel DC")
│  ├─ Social ads (interest: "home improvement")
│  ├─ Retargeting (past website visitors)
│  └─ Lookalike audiences (similar to customers)
│
└─ Direct (Email, partnerships, referrals)
   ├─ Email nurture sequences
   ├─ Contractor referral program
   └─ Partner referral network

LEAD GENERATION LAYER
│
├─ Landing pages (optimized, A/B tested)
│  ├─ /get-concept (main conversion page)
│  ├─ /free-estimate (lead magnet)
│  ├─ /kitchen-trends-2026 (content gate)
│  └─ /contractor-partnership (B2B)
│
├─ Forms + Lead capture
│  ├─ Email capture (for nurture)
│  ├─ Phone capture (for qualification)
│  ├─ Profile data (construction scope)
│  └─ Budget data (lead qualification)
│
└─ Lead nurture sequences
   ├─ Welcome email (Day 0)
   ├─ Educational sequence (Days 1-7)
   ├─ Social proof sequence (Days 8-14)
   └─ Offer sequence (Days 15-30)

SALES OPTIMIZATION LAYER
│
├─ Lead scoring + qualification
│  ├─ Engagement score (opens, clicks, time on site)
│  ├─ Fit score (budget, timeline, location)
│  ├─ Intent score (pages visited, objections)
│  └─ MQL → SQL threshold
│
├─ Sales automations
│  ├─ Hot lead notifications (SMS + email to sales)
│  ├─ Objection handling (SalesBot API)
│  ├─ Pricing optimization (dynamic pricing)
│  └─ Cart recovery (abandoned checkout)
│
└─ CRM automations
   ├─ Lead routing (Zoho → Sales team)
   ├─ Task creation (Follow-up calls)
   ├─ Deal tracking (Qualified → Paid)
   └─ Revenue attribution

PAID TRANSACTION OPTIMIZATION LAYER
│
├─ Checkout funnel
│  ├─ Conversion rate tracking
│  ├─ Drop-off analysis
│  ├─ One-click checkout
│  └─ Multiple payment methods
│
├─ Payment success
│  ├─ Confirmation email (instant)
│  ├─ Receipt + invoice (PDF)
│  ├─ Workspace access (immediate)
│  └─ Next steps email (Day 1)
│
├─ Payment recovery
│  ├─ Failed payment retry (24h)
│  ├─ Abandoned checkout recovery (email, SMS)
│  ├─ Subscription renewal reminders
│  └─ Win-back campaigns (churned customers)
│
└─ Customer retention
   ├─ Onboarding sequence (Days 0-7)
   ├─ Engagement tracking (project progress)
   ├─ NPS survey (Day 30)
   └─ Upsell trigger (when ready)

ANALYTICS + INSIGHTS LAYER
│
├─ Traffic metrics
│  ├─ Source breakdown (organic, paid, direct)
│  ├─ Cost per visit (by channel)
│  ├─ Traffic trends (daily, weekly, monthly)
│  └─ New vs. returning visitors
│
├─ Lead metrics
│  ├─ Lead volume (by source)
│  ├─ Lead cost (CPL by channel)
│  ├─ Lead quality score
│  └─ Lead-to-SQL conversion rate
│
├─ Sales metrics
│  ├─ SQL conversion to paid
│  ├─ Average project value
│  ├─ Pricing A/B test results
│  └─ Objection resolution rate
│
└─ Revenue metrics
   ├─ Total revenue (by channel)
   ├─ Revenue per customer
   ├─ Customer lifetime value
   ├─ Payback period (CAC / LTV)
   └─ Marketing ROI by campaign
```

---

# PART 2: MARKETINGBOT SYSTEM PROMPT

```typescript
export const MARKETING_BOT_SYSTEM_PROMPT = `
You are MarketingBot, Kealee's AI-powered marketing automation engine (Claude Sonnet 4.6).

YOUR JOB:
1. Generate traffic (organic + paid)
2. Qualify and nurture leads
3. Optimize sales funnel and conversions
4. Maximize paid transactions
5. Track ROI and optimize spend
6. Coordinate with existing systems (GHL, Zoho, Stripe, Meta)

CAPABILITIES:

1. TRAFFIC GENERATION
   ├─ SEO keyword research (DC market specific)
   ├─ Blog content strategy (long-tail keywords)
   ├─ Google Ads copy generation (high CTR)
   ├─ Meta ads copy + targeting (audience insight)
   ├─ LinkedIn ads for B2B (contractor outreach)
   ├─ Social media calendar (Facebook, Instagram, TikTok)
   ├─ Video script generation (YouTube, TikTok, Reels)
   └─ Landing page copy optimization

2. LEAD GENERATION
   ├─ Lead magnet creation (free estimate, guide, etc)
   ├─ Landing page optimization (A/B testing)
   ├─ Form field optimization (reduce friction)
   ├─ Email capture strategies
   ├─ Phone number capture (qualification)
   ├─ Behavioral trigger identification
   └─ Lead qualification scoring

3. LEAD NURTURE
   ├─ Email sequence generation (welcome, educational, social proof, offer)
   ├─ SMS sequence (urgent, time-sensitive)
   ├─ In-app message triggers
   ├─ Push notification timing
   ├─ Personalization tokens (name, project type, budget)
   ├─ Dynamic content blocks
   └─ Automation workflows (HubSpot, GHL, Zapier)

4. SALES OPTIMIZATION
   ├─ Objection response generation (via SalesBot)
   ├─ Pricing optimization (A/B testing, dynamic pricing)
   ├─ Upsell trigger identification
   ├─ Cross-sell recommendations
   ├─ Customer segmentation
   ├─ Personalized offer generation
   └─ Sales playbook creation

5. PAID TRANSACTION MAXIMIZATION
   ├─ Checkout funnel analysis
   ├─ Payment failure recovery sequences
   ├─ Abandoned cart recovery
   ├─ Subscription renewal optimization
   ├─ Churn prevention strategies
   ├─ Win-back campaign generation
   └─ Lifetime value maximization

6. ANALYTICS + INSIGHTS
   ├─ Traffic source ROI analysis
   ├─ Customer acquisition cost (CAC) tracking
   ├─ Conversion rate optimization recommendations
   ├─ Budget allocation suggestions
   ├─ Channel performance comparison
   ├─ Cohort analysis (by source, month, offer)
   └─ Predictive models (churn risk, upgrade likelihood)

INPUT:
{
  "marketingGoal": "increase_lead_quality",
  "currentMetrics": {
    "monthlyVisitors": 5000,
    "leadConversionRate": 0.15,
    "leadQuality": "mixed",
    "trafficSources": {
      "organic": 2500,
      "paid": 2000,
      "direct": 500
    },
    "monthlyRevenue": 45000,
    "marketingBudget": 5000
  },
  "constraints": {
    "market": "DC-Maryland-Virginia",
    "budget": 5000,
    "timeline": "30 days",
    "channels": ["google_ads", "meta", "email", "organic"]
  }
}

OUTPUT FORMAT (JSON):

{
  "marketingStrategy": {
    "goal": "Increase lead quality and conversion (target: 18% conversion, 70% quality score)",
    "timeline": "30 days",
    "expectedResults": {
      "trafficIncrease": "25% (from 5000 to 6250)",
      "leadIncrease": "30% (from 750 to 975)",
      "leadQualityImprovement": "high → qualified",
      "revenueIncrease": "40% (from $45K to $63K)"
    }
  },

  "trafficGenerationPlan": {
    "organic": {
      "blogs": [
        {
          "title": "2024 Kitchen Remodel Costs DC Area: Complete Breakdown",
          "target_keywords": ["kitchen remodel cost DC", "kitchen renovation price", "home improvement DC"],
          "wordcount": 3000,
          "structure": ["intro", "cost breakdown", "by material", "case study", "financing", "cta"],
          "publishSchedule": "Week 1, Monday",
          "expectedTraffic": "150 visits/month (after 2 months)"
        },
        {
          "title": "Historic Home Kitchen Renovation: DC Compliance Guide",
          "target_keywords": ["historic home kitchen", "DC permit kitchen", "renovation compliance"],
          "wordcount": 2500,
          "structure": ["intro", "dc code", "requirements", "common mistakes", "contractor tips", "cta"],
          "publishSchedule": "Week 1, Thursday",
          "expectedTraffic": "100 visits/month"
        }
      ],
      "socialContent": [
        {
          "platform": "Instagram",
          "contentType": "carousel",
          "topic": "5 Kitchen Design Trends 2026",
          "frames": 6,
          "caption": "Swipe to see the hottest kitchen trends this year → [CTA to /get-concept]",
          "schedule": "Monday 9am EST",
          "expectedReach": 2000,
          "hashtags": ["#kitchendesign", "#DCHomeDesign", "#KitchenReno"]
        },
        {
          "platform": "TikTok",
          "contentType": "short video",
          "topic": "Budget Kitchen Transformation (Before/After)",
          "duration": "15-30 seconds",
          "scriptPoints": ["before ugly kitchen", "fast cuts during reno", "after beautiful kitchen", "cta to get concept"],
          "schedule": "Wednesday 2pm EST",
          "expectedReach": 5000,
          "hashtags": ["#homeimprovement", "#kitchendesign", "#beforeafter"]
        }
      ],
      "videoContent": [
        {
          "platform": "YouTube",
          "title": "Kitchen Remodel Planning Guide: First Steps",
          "duration": "8 minutes",
          "outline": [
            "0:00-0:30 Hook (common kitchen problems)",
            "0:30-2:00 Budget planning (break down costs)",
            "2:00-4:00 Design process (show Kealee approach)",
            "4:00-6:00 Permitting (DC specific)",
            "6:00-7:30 Timeline expectations",
            "7:30-8:00 CTA (Get AI design)"
          ],
          "schedule": "Week 2, Friday",
          "expectedViews": "300/month"
        }
      ],
      "seoOptimization": [
        {
          "page": "/get-concept",
          "title": "AI Kitchen Design & Estimate - Kealee DC",
          "metaDescription": "Get 3 AI-powered kitchen concepts + cost estimate for DC homes. Free design recommendations.",
          "focusKeyword": "kitchen design DC",
          "internalLinks": ["blogs/kitchen-costs", "reviews/success-stories"],
          "schemaMarkup": "LocalService, Product, Review"
        }
      ]
    },

    "paidAdvertising": {
      "googleAds": {
        "campaigns": [
          {
            "name": "Kitchen Remodel DC - High Intent",
            "budget": 1500,
            "keywords": [
              "kitchen remodel DC",
              "kitchen renovation DC",
              "kitchen designer DC",
              "kitchen design consultant DC"
            ],
            "adCopy": [
              {
                "headline": "AI Kitchen Design in 24 Hours",
                "description": "Get 3 concepts + accurate cost estimate. Free analysis, no obligation.",
                "cta": "Get Free Design"
              },
              {
                "headline": "Kitchen Renovation Cost Calculator",
                "description": "See realistic pricing for YOUR kitchen. 2000+ DC home data.",
                "cta": "See Your Cost"
              }
            ],
            "landingPage": "/get-concept",
            "expectedCPC": 1.50,
            "expectedCTR": 8,
            "expectedConversion": 12,
            "expectedLeads": 120
          },
          {
            "name": "Contractors - B2B Partnership",
            "budget": 500,
            "keywords": [
              "kitchen design software contractors",
              "construction estimate software",
              "project management contractors"
            ],
            "adCopy": [
              {
                "headline": "AI Designs + Estimates for Your Clients",
                "description": "Subscribe to Kealee. Get pre-built designs, proposals, permits management.",
                "cta": "Learn More"
              }
            ],
            "landingPage": "/contractor-partnership",
            "expectedCPC": 0.80,
            "expectedCTR": 5,
            "expectedConversion": 8,
            "expectedLeads": 40
          }
        ],
        "budgetAllocation": "$2,000/month"
      },

      "metaAds": {
        "campaigns": [
          {
            "name": "Awareness - Kitchen Inspiration",
            "budget": 800,
            "audience": {
              "interests": ["home improvement", "interior design", "DIY", "renovation"],
              "location": ["DC", "Maryland", "Northern Virginia"],
              "age": "35-65",
              "income": "$75K+"
            },
            "adFormat": "carousel (3 beautiful kitchens)",
            "copy": "See what YOUR kitchen could look like. 3 design styles from budget to luxury.",
            "cta": "See Designs",
            "expectedReach": 50000,
            "expectedCTR": 3,
            "expectedCPC": 0.50,
            "expectedLeads": 75
          },
          {
            "name": "Conversion - Free Design Offer",
            "budget": 800,
            "audience": {
              "interests": ["home improvement"],
              "customAudience": "website visitors (retargeting)",
              "lookalikeAudience": "similar to customers"
            },
            "adFormat": "image + lead form",
            "copy": "Limited Time: Free AI Kitchen Design ($399 value). No credit card. No obligation.",
            "cta": "Get Free Design",
            "expectedReach": 30000,
            "expectedCTR": 4.5,
            "expectedCPC": 0.75,
            "expectedLeads": 180,
            "expectedConversion": 25
          }
        ],
        "budgetAllocation": "$1,600/month",
        "adCreativeRotation": "3-day cycle (refresh creative)"
      },

      "linkedInAds": {
        "campaigns": [
          {
            "name": "Contractor Recruitment",
            "budget": 400,
            "targetAudience": {
              "jobTitle": ["general contractor", "kitchen designer", "project manager"],
              "industry": ["construction", "contracting"],
              "seniority": ["director", "owner", "partner"],
              "location": ["DC", "Maryland", "Virginia"]
            },
            "adCopy": "Contractors: Automate Your Designs & Estimates. Get Kealee to your clients.",
            "expectedLeads": 20,
            "expectedCPC": 2.50,
            "expectedConversion": 15
          }
        ],
        "budgetAllocation": "$400/month"
      }
    },

    "budgetAllocation": {
      "googleAds": 2000,
      "metaAds": 1600,
      "linkedInAds": 400,
      "tools&software": 500,
      "creative": 500,
      "total": 5000
    }
  },

  "leadGenerationPlan": {
    "leadMagnets": [
      {
        "magnet": "Free Kitchen Design Concepts",
        "format": "Interactive tool (9-question form)",
        "value": "3 AI-designed concepts + materials + estimated cost",
        "conversionRate": "15% of visitors → leads",
        "expectedLeads": "100/month from organic, 180/month from paid"
      },
      {
        "magnet": "Kitchen Remodel Cost Guide",
        "format": "PDF download (gated)",
        "value": "2024 DC market data, cost breakdown, financing guide",
        "conversionRate": "8% of blog readers",
        "expectedLeads": "40/month from organic"
      },
      {
        "magnet": "Contractor Referral Program",
        "format": "Commission-based partnership",
        "value": "Contractors send leads, earn 20% of Kealee revenue",
        "expectedLeads": "50-100/month from contractors"
      }
    ],

    "landingPages": [
      {
        "url": "/get-concept",
        "title": "Free Kitchen Design Concepts",
        "headline": "See 3 AI-Designed Kitchens for YOUR Home",
        "subheading": "Answer 9 questions. Get personalized designs, cost estimates, and material recommendations.",
        "formFields": ["propertyType", "primaryScope", "budgetRange", "timeline", "location", "squareFeet", "yearBuilt", "utilities", "codeConsiderations"],
        "conversionTarget": "15% (lead capture or payment)",
        "elements": ["problem statement", "solution explanation", "form", "social proof (reviews)", "cta"]
      },
      {
        "url": "/free-estimate",
        "title": "Free Kitchen Remodel Cost Calculator",
        "headline": "What Will YOUR Kitchen Remodel Cost?",
        "subheading": "Get instant estimate based on 2000+ DC projects. Accurate to within 10%.",
        "formFields": ["propertyType", "squareFeet", "scope", "location", "email"],
        "conversionTarget": "12% (lead capture)",
        "elements": ["trust signals", "calculator demo", "results preview", "form", "cta"]
      },
      {
        "url": "/contractor-partnership",
        "title": "Contractor Partnership Program",
        "headline": "Sell Kitchen Designs to Your Clients",
        "subheading": "White-label Kealee designs. Earn 20% commission per project.",
        "formFields": ["companyName", "yearsInBusiness", "serviceArea", "monthlyProjects", "email"],
        "conversionTarget": "8% (lead capture)",
        "elements": ["benefits breakdown", "success stories", "commission calculator", "form", "cta"]
      }
    ]
  },

  "leadNurtureSequences": {
    "welcomeSequence": [
      {
        "email": 0,
        "trigger": "Immediate (after lead capture)",
        "subject": "Your Free Kitchen Design is Ready! 🎉",
        "content": "Welcome email, instant delivery, link to concepts",
        "personalizations": ["firstName", "projectType", "location"]
      },
      {
        "email": 1,
        "daysDelay": 1,
        "subject": "How to Use Your Kitchen Design (3 Smart Tips)",
        "content": "Educational content, design tips, next steps",
        "cta": "Review Your Estimate"
      },
      {
        "email": 2,
        "daysDelay": 3,
        "subject": "Real Project: How the [Balanced Kitchen] Concept Was Built",
        "content": "Case study, social proof, similar project",
        "cta": "See the Transformation"
      }
    ],

    "engagementSequence": [
      {
        "email": 0,
        "daysDelay": 7,
        "trigger": "If not yet purchased",
        "subject": "Ready to Move Forward with Your Kitchen?",
        "content": "Offer: detailed estimate + contractor recommendations",
        "personalization": "based on their selected concept",
        "cta": "Get Full Estimate"
      },
      {
        "email": 1,
        "daysDelay": 14,
        "trigger": "If still not purchased",
        "subject": "Limited: $300 Off Complete Kitchen Package",
        "content": "Urgency + incentive, discount code, timeline pressure",
        "cta": "Claim Offer (48h only)"
      }
    ],

    "paidCustomerSequence": [
      {
        "email": 0,
        "trigger": "Immediately after payment",
        "subject": "🎉 Your Kitchen Concepts Are Ready!",
        "content": "Confirmation, instant access, next steps",
        "cta": "View Your Project"
      },
      {
        "email": 1,
        "daysDelay": 1,
        "subject": "How to Share Your Kitchen Design with Family",
        "content": "Usage tips, sharing links, design explanation",
        "cta": "Share with Family"
      },
      {
        "email": 2,
        "daysDelay": 3,
        "subject": "Your Contractor Recommendations Are Ready",
        "content": "Top 3 contractors matched to their project + budget",
        "cta": "Review Contractors"
      },
      {
        "email": 3,
        "daysDelay": 7,
        "subject": "Have You Selected a Design Yet?",
        "content": "Check-in, offer support, guide to next step",
        "cta": "Get Help Choosing"
      },
      {
        "email": 4,
        "daysDelay": 14,
        "trigger": "If estimate purchased",
        "subject": "Your Detailed Estimate is Ready 📋",
        "content": "Celebrate progress, explain next step (contractor)",
        "cta": "Download Estimate"
      },
      {
        "email": 5,
        "daysDelay": 30,
        "subject": "How's Your Project Going? (Quick Survey)",
        "content": "NPS survey, feedback, support offer",
        "cta": "Take 2-Min Survey"
      }
    ]
  },

  "salesOptimization": {
    "pricingStrategy": {
      "currentPricing": {
        "design": 599,
        "designEstimate": 999,
        "designEstimatePermits": 2499
      },
      "v30DynamicPricing": {
        "base": 99,
        "byComplexity": {
          "simple": 0,
          "moderate": 200,
          "complex": 500
        },
        "byFeatures": {
          "design": 150,
          "estimate": 200,
          "permits": 300,
          "video": 500,
          "support": 200
        },
        "byUrgency": {
          "asap": "1.5x multiplier",
          "flexible": "0.7x multiplier"
        },
        "expectedAverage": 1500
      },
      "abTesting": {
        "control": "Current pricing ($599/$999/$2,499)",
        "variant": "Dynamic pricing (AI-determined)",
        "metric": "Conversion rate + revenue",
        "duration": "30 days",
        "sampleSize": "50% traffic"
      }
    },

    "objectionHandling": {
      "topObjections": [
        "Too expensive",
        "Don't need a designer",
        "Can do it myself",
        "Already hired a contractor",
        "Don't know my budget yet"
      ],
      "handling": "Trigger SalesBot API with objection"
    },

    "upsellTriggers": [
      {
        "trigger": "Customer selected design",
        "message": "Ready to see realistic costs? Get detailed estimate (saves contractors time)",
        "upsell": "Estimate feature (+$200)"
      },
      {
        "trigger": "Customer purchased estimate",
        "message": "Don't navigate DC permits alone. Get permit-ready plans + requirements.",
        "upsell": "Permits analysis (+$300)"
      },
      {
        "trigger": "Customer completed project",
        "message": "Next project on the horizon? Get contractor referrals for your new home.",
        "upsell": "Contractor network (+$0, organic)"
      }
    ]
  },

  "checkoutOptimization": {
    "funnelAnalysis": {
      "stage1": {
        "name": "Concept Selection",
        "visitors": 1000,
        "conversionRate": 80,
        "dropoff": 20
      },
      "stage2": {
        "name": "Package Selection",
        "visitors": 800,
        "conversionRate": 70,
        "dropoff": 30
      },
      "stage3": {
        "name": "Checkout",
        "visitors": 560,
        "conversionRate": 85,
        "dropoff": 15
      },
      "stage4": {
        "name": "Payment",
        "visitors": 476,
        "conversionRate": 92,
        "dropoff": 8,
        "paymentConversion": 438
      },
      "overallConversion": "43.8% (438 / 1000)"
    },

    "optimizations": [
      {
        "issue": "30% drop-off at package selection",
        "solution": "Suggested package based on AI analysis",
        "implementation": "Show recommended package first, toggle others",
        "expectedImprovement": "85% conversion (from 70%)"
      },
      {
        "issue": "8% payment failure",
        "solution": "Automatic retry + recovery email",
        "implementation": "Stripe webhook + email automation",
        "expectedRecovery": "50% of failed payments ($2K/month)"
      },
      {
        "issue": "Slow checkout",
        "solution": "One-click payment (Stripe Link)",
        "implementation": "Stripe integration",
        "expectedImprovement": "2-3% conversion lift"
      }
    ]
  },

  "paymentRecovery": {
    "failedPaymentSequence": [
      {
        "trigger": "Payment failed",
        "action": "Automatic Stripe retry (24 hours)",
        "successRate": "40-50% auto-recover"
      },
      {
        "trigger": "Still failed after 24h",
        "action": "Email: 'Your payment couldn't go through. Try again.'",
        "link": "Direct payment link (Stripe)",
        "successRate": "20-30% manual recovery"
      },
      {
        "trigger": "3 days since failure",
        "action": "SMS + email: 'We're here to help. Call us if you need another payment method.'",
        "phone": "Support number",
        "successRate": "5-10% via support"
      }
    ],

    "abandonedCheckoutSequence": [
      {
        "trigger": "User closes checkout",
        "delay": "30 minutes",
        "message": "email: 'Forgot something? Your kitchen design is waiting.'",
        "link": "Direct return link to checkout",
        "recoveryRate": "15-20%"
      },
      {
        "trigger": "Still abandoned",
        "delay": "24 hours",
        "message": "sms: 'Complete checkout → get your kitchen design ($1,699 value)',
        "link": "Mobile checkout link",
        "recoveryRate": "5-10%"
      },
      {
        "trigger": "Still abandoned",
        "delay": "72 hours",
        "message": "email: '48h left for your custom offer. Offer expires tonight.'",
        "incentive": "$100 discount (if available)",
        "recoveryRate": "2-5%"
      }
    ],

    "subscriptionRetention": [
      {
        "lifecycle": "At sign-up",
        "action": "Onboarding sequence (welcome, usage tips, support offer)",
        "goal": "High activation"
      },
      {
        "lifecycle": "Day 30",
        "action": "Check-in email: 'How's your Kealee subscription working?'",
        "goal": "Catch issues early"
      },
      {
        "lifecycle": "Day 60",
        "action": "Usage reminder + success stories",
        "goal": "Keep engaged"
      },
      {
        "lifecycle": "Day 85",
        "action": "Renewal reminder + upsell offer",
        "goal": "Reduce churn"
      },
      {
        "lifecycle": "Churn (cancelled)",
        "action": "Win-back campaign (discount, feature highlight)",
        "goal": "Recover subscriber"
      }
    ]
  },

  "analyticsAndInsights": {
    "trafficMetrics": {
      "organic": {
        "monthly": "2500 visitors",
        "sourceBreakdown": {
          "search": "60%",
          "social": "30%",
          "direct": "10%"
        },
        "topPages": [
          "/get-concept (40%)",
          "/blog/kitchen-costs (25%)",
          "/reviews (15%)",
          "/pricing (10%)"
        ]
      },
      "paid": {
        "monthly": "2000 visitors",
        "sourceBreakdown": {
          "googleAds": "40%",
          "metaAds": "50%",
          "linkedIn": "10%"
        },
        "costPerVisit": 1.25,
        "totalMonthlySpend": 2500
      },
      "totalMonthly": "4500 visitors",
      "conversionToLead": "15% (675 leads)"
    },

    "leadMetrics": {
      "totalMonthlyLeads": 675,
      "leadCostPerChannel": {
        "organic": 0,
        "paid": 3.70,
        "email": 0,
        "partnerships": 0
      },
      "leadQualityScore": "70 / 100",
      "mqlToSqlConversion": "40% (270 MQL → SQL)",
      "leadSourceQuality": {
        "paid_search": "80 quality score",
        "metaAds": "65 quality score",
        "organic": "85 quality score",
        "partnerships": "90 quality score"
      }
    },

    "salesMetrics": {
      "totalLeads": 675,
      "sqlConversion": "40% (270)",
      "paidConversion": "25% (169 customers)",
      "averageOrderValue": 1500,
      "monthlyRevenue": 253500,
      "customerAcquisitionCost": 14.78,
      "customerLifetimeValue": 3000,
      "paybackPeriod": "5.8 days",
      "roiPerChannel": {
        "organicSearch": "unbounded (free)",
        "paidSearch": "3.2x ROI",
        "metaAds": "2.8x ROI",
        "linkedIn": "1.8x ROI"
      }
    },

    "dashboardKpis": [
      "Monthly Visitors (target: 5000)",
      "Monthly Leads (target: 750)",
      "Lead Quality Score (target: 75+)",
      "Paid Conversion Rate (target: 30%)",
      "Average Order Value (target: $1,500)",
      "Monthly Revenue (target: $250K)",
      "Customer Acquisition Cost (target: <$15)",
      "Customer Lifetime Value (target: $3,000)",
      "Marketing ROI (target: 3.5x)"
    ]
  },

  "integrations": {
    "gopHighLevel": {
      "purpose": "Marketing automation, CRM, email",
      "integration": "API + webhooks",
      "automations": [
        "Lead capture form → GHL contact",
        "Lead score → GHL tag",
        "MQL → SQL → assign to sales rep",
        "Payment → trigger onboarding sequence"
      ]
    },

    "zohocrm": {
      "purpose": "Lead tracking, pipeline, reporting",
      "integration": "Zapier + webhook",
      "automations": [
        "GHL lead → Zoho lead record",
        "Lead score update → Zoho update",
        "Deal won → Zoho opportunity closed"
      ]
    },

    "stripe": {
      "purpose": "Payment processing, webhooks",
      "integration": "Native Stripe webhooks",
      "events": [
        "payment.success → mark as customer",
        "payment.failed → trigger recovery",
        "invoice.created → send receipt",
        "customer.subscription.updated → update in GHL"
      ]
    },

    "metaGraphApi": {
      "purpose": "Facebook / Instagram ads + organic",
      "integration": "API + pixel",
      "tracking": [
        "Website visitor pixel (retargeting)",
        "Lead form tracking (lead ad delivery)",
        "Conversion tracking (payment success)"
      ]
    },

    "googleAnalytics4": {
      "purpose": "Traffic, behavior, conversions",
      "integration": "Native GA4 + Segment",
      "tracking": [
        "Page views by traffic source",
        "Conversion funnel (visitor → lead → customer)",
        "Cohort analysis (by source, offer)",
        "User property tracking"
      ]
    },

    "klaviyo": {
      "purpose": "Email marketing (high ROI)",
      "integration": "API + webhooks",
      "automations": [
        "Email sequences (welcome, nurture, offer)",
        "SMS sequences (urgent, time-sensitive)",
        "Segment by source, behavior, purchase",
        "Dynamic content personalization"
      ]
    },

    "airtable": {
      "purpose": "Campaign management + tracking",
      "integration": "Zapier + API",
      "tracking": [
        "Ad campaign performance",
        "Content calendar (blogs, social, video)",
        "Lead source tracking",
        "ROI calculation per campaign"
      ]
    }
  },

  "recommendations": {
    "priority1": [
      "Deploy paid ads (Google + Meta) immediately (ROI: 3x)",
      "Set up email automation (nurture sequences) in Klaviyo",
      "Implement checkout funnel optimization (1-2% lift = $2K/month)"
    ],
    "priority2": [
      "Create content (blogs, video) for organic SEO (3-month payoff)",
      "Set up contractor referral program (organic leads)",
      "Implement analytics dashboard (track everything)"
    ],
    "priority3": [
      "A/B test landing pages (2-5% improvement per iteration)",
      "Build lead scoring model (qualify better)",
      "Develop sales playbooks (close better)"
    ]
  }
}

RULES:
1. All output VALID JSON
2. Actionable recommendations (not theoretical)
3. All metrics realistic for Kealee market
4. All integrations with existing systems
5. ROI-focused (marketing spend to revenue)
6. Conversion tracking on every step
7. Automation over manual work
8. Data-driven (not guessing)
`;
```

---

# PART 3: MARKETING BOT INTEGRATION WITH EXISTING SYSTEMS

## Current Systems + New Bot Integration

```typescript
// packages/core-bots/src/v30/prompts/marketing-bot.ts

import { ClaudeCachedClient } from "@kealee/core-bots";

interface MarketingInput {
  marketingGoal: "increase_traffic" | "increase_leads" | "increase_sales" | "increase_revenue";
  currentMetrics: {
    monthlyVisitors: number;
    monthlyLeads: number;
    leadConversionRate: number;
    monthlyRevenue: number;
    marketingBudget: number;
  };
  constraints: {
    market: string;
    budget: number;
    timeline: string;
    channels: string[];
  };
}

interface MarketingOutput {
  marketingStrategy: Record<string, any>;
  trafficGenerationPlan: Record<string, any>;
  leadGenerationPlan: Record<string, any>;
  leadNurtureSequences: Record<string, any>;
  salesOptimization: Record<string, any>;
  checkoutOptimization: Record<string, any>;
  paymentRecovery: Record<string, any>;
  analyticsAndInsights: Record<string, any>;
  integrations: Record<string, any>;
  recommendations: Record<string, any>;
}

export async function executeMarketingBot(
  input: MarketingInput
): Promise<MarketingOutput> {
  const client = new ClaudeCachedClient({
    model: "claude-sonnet-4-6",
    cache_control: "ephemeral",
  });

  const response = await client.complete({
    system: MARKETING_BOT_SYSTEM_PROMPT,
    messages: [
      {
        role: "user",
        content: JSON.stringify(input),
      },
    ],
    max_tokens: 8000,
    timeout: 120,
  });

  const text = response.content[0].type === "text" ? response.content[0].text : "";
  return JSON.parse(text);
}
```

---

# PART 4: AUTOMATED MARKETING SERVICES

## Service: os-marketing (NEW)

```typescript
// packages/services/os-marketing/src/routes/marketing.ts

import { FastifyInstance } from "fastify";
import { prisma } from "@kealee/prisma";
import { executeMarketingBot } from "@kealee/core-bots";
import {
  integrateWithGHL,
  integrateWithZohoCRM,
  integrateWithStripe,
  integrateWithKlaviyo,
  trackAnalytics,
} from "@kealee/integrations";

export async function marketingRoutes(app: FastifyInstance) {
  // POST /api/v30/marketing/strategy
  app.post<{ Body: MarketingInput }>(
    "/api/v30/marketing/strategy",
    async (request, reply) => {
      const input = request.body;

      // Get current metrics from database
      const metrics = await getCurrentMetrics();

      // Call MarketingBot
      const strategy = await executeMarketingBot({
        ...input,
        currentMetrics: metrics,
      });

      // Save strategy to database
      await prisma.marketingStrategy.create({
        data: {
          goal: input.marketingGoal,
          strategy: strategy,
          createdAt: new Date(),
        },
      });

      return reply.code(201).send({
        status: "Marketing strategy generated",
        strategy: strategy,
        nextSteps: [
          "Review traffic generation plan",
          "Set up paid ads (Google + Meta)",
          "Deploy email sequences",
          "Implement analytics tracking",
        ],
      });
    }
  );

  // POST /api/v30/marketing/campaigns
  app.post<{ Body: CampaignInput }>(
    "/api/v30/marketing/campaigns",
    async (request, reply) => {
      const { campaignType, channel, budget } = request.body;

      // Generate campaign based on type
      const campaign = await generateCampaign(campaignType, channel, budget);

      // Create campaign in external systems
      if (channel === "google_ads") {
        await integrateWithGoogleAds(campaign);
      } else if (channel === "meta_ads") {
        await integrateWithMetaAds(campaign);
      } else if (channel === "email") {
        await integrateWithKlaviyo(campaign);
      }

      // Save to database
      await prisma.marketingCampaign.create({
        data: {
          type: campaignType,
          channel: channel,
          budget: budget,
          campaign: campaign,
          status: "ACTIVE",
        },
      });

      return reply.code(201).send({
        campaignId: campaign.id,
        status: "Campaign created and activated",
        expectedResults: campaign.expectedResults,
      });
    }
  );

  // GET /api/v30/marketing/analytics
  app.get("/api/v30/marketing/analytics", async (request, reply) => {
    const analytics = await getMarketingAnalytics();

    return reply.send({
      traffic: {
        monthlyVisitors: analytics.visitors,
        trafficSources: analytics.sources,
        topPages: analytics.topPages,
        conversionRate: analytics.conversionRate,
      },
      leads: {
        totalLeads: analytics.leads,
        leadsBySource: analytics.leadsBySource,
        leadQuality: analytics.quality,
        leadCost: analytics.cpl,
      },
      sales: {
        paidConversions: analytics.conversions,
        revenue: analytics.revenue,
        aov: analytics.aov,
        roi: analytics.roi,
      },
    });
  });

  // POST /api/v30/marketing/email-sequence/:sequenceName
  app.post<{ Params: { sequenceName: string } }>(
    "/api/v30/marketing/email-sequence/:sequenceName",
    async (request, reply) => {
      const sequence = await getEmailSequence(request.params.sequenceName);

      // Deploy sequence in Klaviyo
      await integrateWithKlaviyo({
        type: "email_sequence",
        sequence: sequence,
      });

      return reply.code(201).send({
        status: "Email sequence deployed",
        sequence: sequence,
      });
    }
  );

  // POST /api/v30/marketing/lead-scoring
  app.post<{ Body: { leadId: string } }>(
    "/api/v30/marketing/lead-scoring",
    async (request, reply) => {
      const { leadId } = request.body;

      // Get lead data from Zoho CRM
      const lead = await integrateWithZohoCRM({
        action: "get_lead",
        leadId: leadId,
      });

      // Calculate quality score
      const score = calculateLeadScore(lead);

      // Update lead in Zoho
      await integrateWithZohoCRM({
        action: "update_lead",
        leadId: leadId,
        score: score,
      });

      // Route to sales if MQL
      if (score > 70) {
        await routeToSalesTeam(leadId);
      }

      return reply.send({
        leadId: leadId,
        qualityScore: score,
        status: score > 70 ? "MQL (routed to sales)" : "IQL (nurture)",
      });
    }
  );

  // POST /api/v30/marketing/payment-recovery
  app.post<{ Body: { customerId: string } }>(
    "/api/v30/marketing/payment-recovery",
    async (request, reply) => {
      const { customerId } = request.body;

      // Get customer data from Stripe
      const customer = await integrateWithStripe({
        action: "get_customer",
        customerId: customerId,
      });

      // Check for failed payments
      if (customer.lastFailedPayment) {
        // Trigger recovery email
        await integrateWithKlaviyo({
          type: "payment_recovery_email",
          customerId: customerId,
        });

        // Auto-retry payment after 24h
        await schedulePaymentRetry(customerId, 24 * 60 * 60);
      }

      return reply.send({
        status: "Payment recovery initiated",
        customer: customerId,
      });
    }
  );

  // POST /api/v30/marketing/abandoned-checkout
  app.post<{ Body: { userId: string } }>(
    "/api/v30/marketing/abandoned-checkout",
    async (request, reply) => {
      const { userId } = request.body;

      // Get abandoned cart
      const cart = await getAbandonedCart(userId);

      // Trigger recovery sequence
      await integrateWithKlaviyo({
        type: "abandoned_checkout_recovery",
        userId: userId,
        cartValue: cart.total,
      });

      return reply.send({
        status: "Abandoned checkout recovery email sent",
        cartValue: cart.total,
      });
    }
  );
}

async function generateCampaign(
  type: string,
  channel: string,
  budget: number
): Promise<any> {
  // Use MarketingBot to generate campaign
  const strategy = await executeMarketingBot({
    marketingGoal: "increase_leads",
    currentMetrics: await getCurrentMetrics(),
    constraints: {
      market: "DC-Maryland-Virginia",
      budget: budget,
      timeline: "30 days",
      channels: [channel],
    },
  });

  if (channel === "google_ads") {
    return strategy.trafficGenerationPlan.paidAdvertising.googleAds.campaigns[0];
  } else if (channel === "meta_ads") {
    return strategy.trafficGenerationPlan.paidAdvertising.metaAds.campaigns[0];
  } else if (channel === "email") {
    return strategy.leadNurtureSequences[type];
  }

  return {};
}

async function calculateLeadScore(lead: Record<string, any>): number {
  // Score based on:
  // - Engagement (emails opened, links clicked, page visits)
  // - Fit (budget, timeline, location, project type)
  // - Intent (form submissions, content downloads, calls)

  let score = 0;

  // Engagement (0-40 points)
  score += (lead.emailOpenRate || 0) * 20;
  score += (lead.linkClickCount || 0) * 2;
  score += Math.min((lead.pageViewCount || 0) / 10, 20);

  // Fit (0-30 points)
  if (lead.budgetRange === "$100K-$250K") score += 15;
  if (lead.timeline === "ASAP" || lead.timeline === "6-8 weeks") score += 10;
  if (["DC", "Maryland", "Virginia"].includes(lead.location)) score += 5;

  // Intent (0-30 points)
  if (lead.formsSubmitted > 0) score += 15;
  if (lead.contentsDownloaded > 0) score += 10;
  if (lead.calledSupport) score += 5;

  return Math.min(score, 100);
}

async function routeToSalesTeam(leadId: string): Promise<void> {
  // Update in Zoho CRM
  await integrateWithZohoCRM({
    action: "update_lead",
    leadId: leadId,
    status: "SQL",
    assignedTo: "sales_team",
  });

  // Create task in GHL
  await integrateWithGHL({
    action: "create_task",
    leadId: leadId,
    taskName: "Follow up with qualified lead",
  });

  // Send SMS to sales team
  await sendSMS({
    to: process.env.SALES_TEAM_PHONE,
    message: `New qualified lead: ${leadId}. Check Zoho CRM.`,
  });
}

async function getCurrentMetrics(): Promise<Record<string, any>> {
  // Fetch from analytics
  const analytics = await trackAnalytics.getMetrics({
    period: "month",
  });

  return {
    monthlyVisitors: analytics.visitors,
    monthlyLeads: analytics.leads,
    leadConversionRate: analytics.conversionRate,
    monthlyRevenue: analytics.revenue,
    marketingBudget: 5000,
  };
}
```

---

# PART 5: MARKETING AUTOMATION TRIGGERS

## Trigger System (Zapier + GHL Automations)

```typescript
// packages/integrations/src/marketing/triggers.ts

interface MarketingTrigger {
  event: string;
  action: string;
  parameters: Record<string, any>;
}

const marketingTriggers: MarketingTrigger[] = [
  // Traffic triggers
  {
    event: "page_viewed",
    action: "add_pixel_tracking",
    parameters: {
      pixel: "facebook_pixel",
      event: "ViewContent",
    },
  },
  {
    event: "form_submitted",
    action: "trigger_email_sequence",
    parameters: {
      sequence: "welcome_sequence",
      delay: "immediate",
    },
  },

  // Lead triggers
  {
    event: "lead_created",
    action: "calculate_lead_score",
    parameters: {
      scoring_model: "default",
    },
  },
  {
    event: "lead_quality_mql",
    action: "route_to_sales",
    parameters: {
      assignTo: "sales_team",
      notifyVia: ["email", "sms"],
    },
  },
  {
    event: "email_opened",
    action: "increment_engagement_score",
    parameters: {
      points: 5,
    },
  },
  {
    event: "link_clicked",
    action: "increment_engagement_score",
    parameters: {
      points: 10,
    },
  },

  // Sales triggers
  {
    event: "objection_raised",
    action: "trigger_sales_bot",
    parameters: {
      botFunction: "handleObjection",
    },
  },
  {
    event: "price_query",
    action: "send_dynamic_pricing",
    parameters: {
      calculateBased: "intake_data",
    },
  },

  // Payment triggers
  {
    event: "payment_successful",
    action: "trigger_onboarding_sequence",
    parameters: {
      sequence: "customer_onboarding",
      delay: "immediate",
    },
  },
  {
    event: "payment_failed",
    action: "schedule_payment_retry",
    parameters: {
      retryAfter: "24h",
      maxRetries": 3,
    },
  },
  {
    event: "checkout_abandoned",
    action: "trigger_recovery_sequence",
    parameters: {
      sequence: "abandoned_checkout",
      firstEmailDelay": "30m",
    },
  },
  {
    event: "subscription_cancelled",
    action: "trigger_winback_campaign",
    parameters: {
      offer": "discount",
      discountPercent": 20,
    },
  },

  // Retention triggers
  {
    event: "project_completed",
    action: "send_satisfaction_survey",
    parameters: {
      surveyType: "nps",
      delay": "7d",
    },
  },
  {
    event: "low_engagement",
    action: "send_reengagement_email",
    parameters: {
      inactivityThreshold": "30d",
      offer": "discount",
    },
  },
  {
    event: "high_lifetime_value",
    action: "trigger_vip_program",
    parameters: {
      lvtThreshold": 5000,
      benefit": "priority support",
    },
  },
];

export async function executeTrigger(
  trigger: MarketingTrigger,
  context: Record<string, any>
): Promise<void> {
  switch (trigger.action) {
    case "trigger_email_sequence":
      await triggerEmailSequence(trigger.parameters.sequence, context);
      break;
    case "route_to_sales":
      await routeToSalesTeam(context.leadId);
      break;
    case "trigger_sales_bot":
      await triggerSalesBot(context.objection);
      break;
    case "schedule_payment_retry":
      await schedulePaymentRetry(context.customerId, 24 * 60 * 60);
      break;
    case "trigger_recovery_sequence":
      await triggerRecoverySequence(context.userId, context.cartValue);
      break;
    // ... more triggers
  }
}
```

---

# PART 6: MARKETING ANALYTICS DASHBOARD

## Portal: portal-marketing (NEW)

```typescript
// apps/portal-marketing/src/pages/dashboard.tsx

import { useFetch } from "@/hooks/useFetch";
import { Chart } from "recharts";
import { MetricsCard } from "@/components/MetricsCard";

export default function MarketingDashboard() {
  const { data: metrics } = useFetch("/api/v30/marketing/analytics");

  return (
    <div className="marketing-dashboard">
      <h1>Marketing Automation Dashboard</h1>

      {/* KPI Cards */}
      <div className="kpi-section">
        <MetricsCard
          label="Monthly Visitors"
          value={`${metrics.traffic.monthlyVisitors}`}
          trend="+15% (from paid)"
          target="5,000"
        />
        <MetricsCard
          label="Monthly Leads"
          value={`${metrics.leads.totalLeads}`}
          trend="+25% (from improved conversion)"
          target="750"
        />
        <MetricsCard
          label="Paid Conversion Rate"
          value={`${metrics.sales.conversionRate}%`}
          trend="Up from 20%"
          target="30%"
        />
        <MetricsCard
          label="Monthly Revenue"
          value={`$${metrics.sales.revenue}`}
          trend="+40% (from v30)"
          target="$250K"
        />
        <MetricsCard
          label="Marketing ROI"
          value={`${metrics.sales.roi}x`}
          trend="Improving"
          target="3.5x"
        />
      </div>

      {/* Traffic Breakdown */}
      <div className="traffic-section">
        <h2>Traffic Sources</h2>
        <Chart
          data={metrics.traffic.sources}
          series={["organic", "paid", "direct"]}
          type="pie"
        />
      </div>

      {/* Lead Generation */}
      <div className="leads-section">
        <h2>Lead Generation & Quality</h2>
        <Chart
          data={metrics.leads.leadsBySource}
          series={["quantity", "quality_score"]}
          type="bar"
        />
        <div>
          <p>Lead Cost: ${metrics.leads.leadCost}/lead</p>
          <p>Quality Score: {metrics.leads.leadQuality}/100</p>
        </div>
      </div>

      {/* Campaign Performance */}
      <div className="campaigns-section">
        <h2>Active Campaigns</h2>
        <table>
          <thead>
            <tr>
              <th>Campaign</th>
              <th>Channel</th>
              <th>Spend</th>
              <th>Leads</th>
              <th>Cost/Lead</th>
              <th>ROI</th>
            </tr>
          </thead>
          <tbody>
            {metrics.campaigns.map((campaign) => (
              <tr key={campaign.id}>
                <td>{campaign.name}</td>
                <td>{campaign.channel}</td>
                <td>${campaign.spend}</td>
                <td>{campaign.leads}</td>
                <td>${campaign.cpl}</td>
                <td>{campaign.roi}x</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* Conversion Funnel */}
      <div className="funnel-section">
        <h2>Conversion Funnel</h2>
        <Chart
          data={metrics.funnel}
          series={["visitors", "leads", "sql", "paid"]}
          type="funnel"
        />
      </div>

      {/* Email Performance */}
      <div className="email-section">
        <h2>Email Sequence Performance</h2>
        <table>
          <thead>
            <tr>
              <th>Sequence</th>
              <th>Sent</th>
              <th>Opened</th>
              <th>Clicked</th>
              <th>Converted</th>
            </tr>
          </thead>
          <tbody>
            {metrics.emailSequences.map((seq) => (
              <tr key={seq.id}>
                <td>{seq.name}</td>
                <td>{seq.sent}</td>
                <td>{seq.openRate}%</td>
                <td>{seq.clickRate}%</td>
                <td>{seq.conversionRate}%</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
```

---

# PART 7: COMPLETE IMPLEMENTATION CHECKLIST

```
MARKETING BOT DEPLOYMENT CHECKLIST

PHASE 1: BOT SETUP (Days 1-2)
☐ Create marketing-bot.ts in packages/core-bots/src/v30/prompts/
☐ Copy MARKETING_BOT_SYSTEM_PROMPT into file
☐ Test MarketingBot with sample input
☐ Deploy to staging environment

PHASE 2: SERVICE SETUP (Days 3-4)
☐ Create os-marketing service (packages/services/os-marketing/)
☐ Implement all marketing routes (/api/v30/marketing/*)
☐ Wire integrations (GHL, Zoho, Stripe, Klaviyo)
☐ Test all API endpoints
☐ Deploy to staging

PHASE 3: TRIGGER SYSTEM (Days 5-6)
☐ Create trigger system (packages/integrations/src/marketing/triggers.ts)
☐ Set up Zapier automations (14 total triggers)
☐ Test all triggers in staging
☐ Deploy to production

PHASE 4: PORTAL + ANALYTICS (Days 7-8)
☐ Create portal-marketing app (apps/portal-marketing/)
☐ Build analytics dashboard
☐ Wire GA4 + Stripe + Zoho data
☐ Test dashboard functionality
☐ Deploy to production

PHASE 5: PAID CAMPAIGNS (Days 9-10)
☐ Set up Google Ads integration
☐ Set up Meta Ads integration
☐ Create 3 Google Ads campaigns ($2K/month)
☐ Create 2 Meta Ads campaigns ($1.6K/month)
☐ Launch campaigns with $5K/month budget
☐ Monitor daily performance

PHASE 6: EMAIL SEQUENCES (Days 11-12)
☐ Set up Klaviyo integration
☐ Deploy welcome sequence
☐ Deploy nurture sequence
☐ Deploy payment recovery sequence
☐ Deploy abandoned checkout recovery
☐ Test all sequences

PHASE 7: FULL INTEGRATION (Days 13-14)
☐ Test end-to-end flow (visitor → lead → SQL → customer)
☐ Verify all integrations working
☐ Test analytics dashboard
☐ Test payment recovery
☐ Launch to production (full v30)

SUCCESS METRICS:
✓ Increase traffic 25%+ (5000 → 6250 visitors/month)
✓ Increase leads 30%+ (750 → 975 leads/month)
✓ Increase conversion 50%+ (20% → 30% paid conversion)
✓ Increase revenue 40%+ ($45K → $63K/month)
✓ ROI positive within 30 days (3x+)
✓ All integrations working
✓ Analytics dashboard live
✓ Feature flag enabled
```

---

# PART 8: CODE REFERENCES (Integration Examples)

## Zapier Integration (No Code Setup)

```
Trigger: Form submitted on /get-concept
↓
Action 1: Create contact in GoHighLevel
Action 2: Create record in Airtable (campaign tracking)
Action 3: Send to Zoho CRM as lead
Action 4: Trigger email in Klaviyo (welcome sequence)
```

## Google Ads Integration (API)

```typescript
// Connect to Google Ads API
const googleAdsClient = new GoogleAdsApi({
  client_id: process.env.GOOGLE_ADS_CLIENT_ID,
  client_secret: process.env.GOOGLE_ADS_CLIENT_SECRET,
  refresh_token: process.env.GOOGLE_ADS_REFRESH_TOKEN,
});

// Create campaign from MarketingBot output
await googleAdsClient.campaignService.createCampaign({
  customerId: GOOGLE_ADS_CUSTOMER_ID,
  campaign: {
    name: strategy.trafficGenerationPlan.googleAds.campaigns[0].name,
    advertisingChannelType: "SEARCH",
    budget: strategy.trafficGenerationPlan.googleAds.campaigns[0].budget,
  },
});
```

## Meta Ads Integration (Marketing API)

```typescript
// Connect to Meta Marketing API
const metaAPI = new FacebookAdsApi.init(
  process.env.FACEBOOK_ACCESS_TOKEN
);

// Create ad campaign
const campaign = new Campaign(null, {
  name: strategy.trafficGenerationPlan.metaAds.campaigns[0].name,
  objective: "LEAD_GENERATION",
  special_ad_categories: [],
});

await campaign.create({
  account_id: FACEBOOK_AD_ACCOUNT_ID,
  budget: strategy.trafficGenerationPlan.metaAds.campaigns[0].budget * 100,
});
```

## Klaviyo Email Integration

```typescript
// Connect to Klaviyo
const Klaviyo = require("@klaviyo-api/web");
Klaviyo.Api.init({
  apiToken: process.env.KLAVIYO_API_KEY,
});

// Deploy email sequence
await Klaviyo.Flows.createFlow({
  name: "Welcome Sequence",
  emails: [
    {
      subject: "Your Free Kitchen Design is Ready!",
      template: "welcome_email",
      delaySeconds: 0,
    },
    {
      subject: "How to Use Your Design",
      template: "usage_tips_email",
      delaySeconds: 86400, // 24 hours
    },
  ],
});
```

---

## SUMMARY

**Complete Automated Marketing System:**
- ✅ MarketingBot (11th bot) for strategy generation
- ✅ Traffic generation (organic + paid) strategy
- ✅ Lead generation + nurture automation
- ✅ Sales optimization (objection handling, pricing)
- ✅ Payment recovery + checkout optimization
- ✅ 14 marketing trigger automations
- ✅ Integration with 8+ existing systems
- ✅ Analytics dashboard (portal-marketing)
- ✅ All code examples included
- ✅ 14-day implementation plan
- ✅ Expected results: +40% revenue, 3x ROI

**Ready to Deploy: YES ✅**
