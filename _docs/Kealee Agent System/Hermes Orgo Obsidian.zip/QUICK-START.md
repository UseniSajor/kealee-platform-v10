# Kealee Agent Execution: Quick Start (5 minutes)

## What You're Getting

A complete **AI-powered construction agent system** for Kealee Platform v20:

- **DesignBot** (Claude Opus 4.6): Converts 9-question intake → 3 design concepts
- **EstimateBot** (Claude Sonnet): Generates cost breakdown with regional adjustments
- **PermitBot** (Claude Sonnet): Autonomous DC/Maryland permit filing
- **Orgo**: Organizational structure & chain routing
- **Obsidian**: Knowledge base (pricing, approvals, permits)
- **Hermes**: Function routing with prompt caching (40–60% cost savings)

## Setup (Copy & Paste)

### Step 1: Copy Implementation Files

```bash
# Navigate to Kealee Platform root
cd /path/to/kealee-platform-v10

# Copy files into your project structure
cp KEALEE-AGENT-IMPLEMENTATION-GUIDE.md docs/
cp orgo-agent-structure.ts packages/core-bots/src/orgo/
cp hermes-function-routing.ts packages/core-bots/src/hermes/
cp obsidian-knowledge-base.ts packages/core-bots/src/obsidian/
cp kealee-integration-example.ts packages/core-bots/src/integration/
cp kealee-integration-points.ts packages/core-bots/src/integration/
```

### Step 2: Install Dependencies

```bash
npm install @anthropic-ai/sdk
```

### Step 3: Set Environment

```bash
# In .env.local
ANTHROPIC_API_KEY="sk-ant-..."
KEALEE_REGION="DMV"
KEALEE_MODE="production"
```

### Step 4: Initialize in Your App

```typescript
// pages/api/concept.ts (or app/api/concept/route.ts)
import { KealeeAgentSystem } from "@/packages/core-bots/src/integration/kealee-integration-example";

const kealeeSystem = new KealeeAgentSystem();

export async function POST(req: Request) {
  const { projectId, userId, intakeAnswers } = await req.json();
  
  const result = await kealeeSystem.executeAIConcept(
    projectId,
    userId,
    intakeAnswers
  );
  
  return Response.json(result);
}
```

## Hello, DesignBot

```typescript
import { KealeeAgentSystem } from "@/packages/core-bots/src/integration/kealee-integration-example";

async function main() {
  const system = new KealeeAgentSystem();
  
  const result = await system.executeAIConcept(
    "proj-123",
    "user-alice",
    {
      property_type: "Single-family home",
      scope: "HVAC upgrade + plumbing",
      budget: "$45,000",
      timeline: "6 weeks",
      location: "Washington DC",
      square_footage: "2,800 SF",
      year_built: "1985",
      utilities: "Natural gas, city water",
      code_compliance: "DC housing code 14-1401",
    }
  );
  
  console.log("✅ Concept ready:");
  console.log(`  ID: ${result.concept.conceptId}`);
  console.log(`  Timeline: ${result.concept.timeline}`);
  console.log(`  Risks: ${result.concept.risks.length}`);
  console.log(`  Images: ${result.concept.images.length}`);
}

main();
```

**Output:**
```
[KeaBotRoot] Starting execution for project proj-123
[Gateway] Routed to chain: CONCEPT
[DesignBot] Starting for project proj-123
[Hermes] Calling claude-opus-4-6 for context proj-123 with cache
[Hermes] Response received. Cache: MISS, Created: 2487, Read: 0

✅ Concept ready:
  ID: concept-proj-123-...
  Timeline: 6 weeks
  Risks: 3
  Images: 6
```

## Key Files & What They Do

| File | Purpose |
|------|---------|
| **KEALEE-AGENT-IMPLEMENTATION-GUIDE.md** | Complete reference documentation |
| **orgo-agent-structure.ts** | KeaBotRoot, Gateway, KeaBotChain, KeaBotExecutor |
| **hermes-function-routing.ts** | Claude API client with prompt caching, event system |
| **obsidian-knowledge-base.ts** | Persistent memory (pricing, approvals, permits) |
| **kealee-integration-example.ts** | KealeeAgentSystem (ready-to-use main class) |
| **kealee-integration-points.ts** | Stripe webhook, portal integration, examples |

## The Three-Layer Stack

```
┌─ ORGO ───────────────────────────────────────┐
│ Organizational Structure                       │
│ • KeaBotRoot (entry point)                   │
│ • Gateway (intent classifier)                │
│ • KeaBotChain (immutable routing)            │
│ • KeaBotExecutor (action runner)             │
└────────────────────────────────────────────────┘
                      ↑ ↓
┌─ OBSIDIAN ────────────────────────────────────┐
│ Contextual Knowledge Base                      │
│ • Concepts (design intent + images)          │
│ • Pricing Rules (from core-rules package)    │
│ • Permit Blueprints (DC DCRA + Maryland)     │
│ • Approval Workflows (gates between stages)  │
│ • Audit Log (all decisions)                  │
└────────────────────────────────────────────────┘
                      ↑ ↓
┌─ HERMES ──────────────────────────────────────┐
│ Function Routing & Execution                  │
│ • ClaudeCachedClient (Anthropic SDK wrapper) │
│ • Prompt Caching (40-60% cost savings)      │
│ • CacheMetricsLogger (performance tracking)  │
│ • FunctionRouter (function call routing)     │
│ • KheaEventEmitter (state change broadcast)  │
└────────────────────────────────────────────────┘
```

## Execution Flow

```
User Input (9-question intake)
    ↓
KeaBotRoot.execute(context)
    ↓
Gateway.classify(intents) → Determine chain stages
    ↓
For each stage:
  [1] DesignBot → Concept
  [2] EstimateBot → Cost breakdown
  [3] PermitBot → Autonomous filing
    ↓
KheaEventEmitter.emit() → Real-time portal updates
    ↓
Cache metrics logged → Analytics dashboard
    ↓
Result stored in Obsidian & Database
```

## Cost Comparison

**Without caching** (old way):
- DesignBot: $0.015 per call
- EstimateBot: $0.003 per call
- PermitBot: $0.003 per call
- **Total per chain: $0.021**

**With caching** (new way, 40-60% savings):
- First project: $0.021 (cache creation)
- Projects 2-5: ~$0.010 each (cache reuse)
- **Average: $0.012 per chain (43% reduction)**

**At 1,000 projects/month:**
- **Without**: $21,000
- **With**: $12,000
- **Savings: $9,000/month** 💰

## Model Lock (Cannot Change Without SESSION 12 Smoke Test)

```typescript
// These are LOCKED until smoke test passes

DesignBot → Claude Opus 4.6    // Complex creative output
EstimateBot → Claude Sonnet    // Cost/timeline analysis
PermitBot → Claude Sonnet      // Autonomous filing
```

## Pricing Rules (Critical)

**NEVER hardcode prices. Always use:**

```typescript
// ✅ Correct
const rules = await obsidian.getPricingRules("DMV", 2026);
const hvacRate = rules.hourlyRates.HVAC.regional;  // $121.60

// ❌ WRONG
const hvacRate = 121.60;  // Hardcoded

// Rules import from:
// packages/core-rules/src/pricing.ts
```

## Approval Gates (Workflow)

Each stage has approval requirements:

| Stage | Approver | Auto-approve | Timeout |
|-------|----------|--------------|---------|
| **Concept** | CLIENT | No | 48h |
| **Estimate** | CLIENT + FINANCE | No | 72h |
| **Permit** | PE + COMPLIANCE | Yes | 24h |

```typescript
// Check if stage can proceed
const approved = await obsidian.canProceedToNextStage(
  conceptId,
  "CONCEPT"
);

// Approve stage
await obsidian.approveConceptRecord(
  conceptId,
  "alice@client.com"
);
```

## Real-Time Portal Updates

Listen for agent completions:

```typescript
system.onEvent("DESIGN_COMPLETE", (projectId, data) => {
  console.log(`Design ready: ${data.conceptId}`);
  // Update UI, send notification, etc.
});

system.onEvent("ESTIMATE_COMPLETE", (projectId, data) => {
  console.log(`Estimate total: $${data.total}`);
});

system.onEvent("PERMIT_FILED", (projectId, data) => {
  console.log(`Filed in ${data.jurisdiction}`);
});

system.onEvent("ERROR", (projectId, data) => {
  console.error(`${data.stage} failed: ${data.error}`);
});
```

## Testing

```bash
# Run smoke tests (all 12 must pass)
npm test -- tests/smoke-12-keabot.test.ts

# Expected output:
# ✓ DesignBot produces valid JSON
# ✓ EstimateBot chains after concept
# ✓ PermitBot chains after estimate
# ✓ Obsidian stores concept correctly
# ✓ Pricing rules load from core-rules
# ✓ Cache metrics recorded
# ✓ Approval workflow blocks estimate
# ✓ Events emit on completion
# ✓ DC DCRA permit blueprint correct
# ✓ Maryland Playwright fields correct
# ✓ No Zem Solutions references
# ✓ Cache hit rate >= 40%
```

## Troubleshooting

### Cache Miss Every Call
→ Re-use context across calls on same project:
```typescript
const ctx = createCacheableContext(projectId, ...);
await claudeClient.callClaudeWithCache(projectId, prompt1);
await claudeClient.callClaudeWithCache(projectId, prompt2);  // Hit
```

### EstimateBot Can't Find Pricing
→ Check Obsidian init:
```typescript
const rules = await obsidian.getPricingRules();
console.log(rules.baselineMultiplier);  // Should be 1.28
```

### PermitBot Files Unapproved Estimate
→ Enforce approval gates:
```typescript
const ready = await obsidian.canProceedToNextStage(estimateId, "ESTIMATE");
if (!ready) throw new Error("Awaiting approval");
```

## Next Steps

1. ✅ Copy files to your project
2. ✅ Set `ANTHROPIC_API_KEY` env var
3. ✅ Run smoke tests (all 12 pass)
4. ✅ Integrate with Next.js API routes
5. ✅ Deploy to Railway + Vercel
6. ✅ Monitor cache metrics in production

## Full Documentation

👉 See **KEALEE-AGENT-IMPLEMENTATION-GUIDE.md** for:
- Complete architecture diagrams
- Prompt caching deep dive
- Integration with Stripe webhooks
- Portal event system setup
- Pricing rules management
- Approval workflow customization
- Deployment checklist

---

**Questions?** Check the implementation guide or your Cursor IDE with `.mdc` configuration.

**Ready?** Copy the files and start building! 🚀
