# Kealee Agent Execution System: Implementation Guide
## Orgo · Obsidian · Hermes

---

## Executive Summary

The Kealee Agent Execution System is a three-layer architecture designed to orchestrate autonomous AI agents (DesignBot, EstimateBot, PermitBot) with built-in approval workflows, prompt caching, and persistent knowledge management.

**Three-layer stack:**
- **Orgo**: Organizational structure (agent roles, execution context, chain routing)
- **Obsidian**: Contextual knowledge base (concepts, pricing, approvals, permits)
- **Hermes**: Function routing & execution (Claude API with prompt caching, event emission)

---

## Architecture Overview

### Layer 1: Orgo (Organizational Structure)

**Purpose**: Manage hierarchical agent roles, execution contexts, and immutable chain routing.

**Components**:
- `KeaBotRoot`: Entry point executor (classifies intent, routes to chain)
- `Gateway`: Intent classifier (determines which chain stages to execute)
- `KeaBotChain`: Immutable execution flow (Design → Estimate → Permit)
- `KeaBotExecutor`: Action runner (calls Claude models with caching)

**Key Concepts**:
- **Immutable Chain**: DesignBot → EstimateBot → PermitBot. No stage executes without prior completion.
- **Chain-gating**: EstimateBot requires completed Concept. PermitBot requires both Concept and Estimate.
- **Context Enrichment**: Each stage enriches ExecutionContext with outputs for downstream stages.

**Execution Flow**:
```
User Input
    ↓
KeaBotRoot.execute(context)
    ↓
Gateway.classify(intents) → [ChainStage[], ...]
    ↓
For each stage in chain:
  - Retrieve prior outputs from Obsidian
  - Call appropriate KeaBot (Design/Estimate/Permit)
  - Store result in Obsidian
  - Check approval gates
  - Emit completion event
    ↓
Return KeaBotChainResult
```

### Layer 2: Obsidian (Knowledge Base)

**Purpose**: Persistent memory for construction projects, pricing rules, approval workflows, permit templates.

**Components**:
- `ConceptRecord`: Stores AI Concept output (design intent, images, assumptions, timeline)
- `PricingRulesRecord`: 2026 DMV baseline rates (NEVER hardcoded in agents)
- `PermitBlueprintRecord`: DC DCRA (REST API) and Maryland county (Playwright automation) templates
- `ApprovalWorkflowRecord`: Defines who approves what at each chain stage
- `AuditEntry`: Complete audit log of all agent actions

**Pricing Rule Hierarchy** (CRITICAL):
```
Obsidian.getPricingRules()
    ↓
imports from packages/core-rules/src/pricing.ts
    ↓
NEVER hardcoded in agent prompts
    ↓
Updates hourly from 24h cache TTL
```

**Storage Pattern**:
```typescript
// Correct: Always use Obsidian
const rules = await obsidian.getPricingRules("DMV", 2026);
const blueprint = await obsidian.getPermitBlueprint("DC_DCRA");

// WRONG: Never hardcode
const rates = { HVAC: 95, ... }; // ❌ WRONG
```

### Layer 3: Hermes (Function Routing & Execution)

**Purpose**: Claude API integration with prompt caching, function routing, and event emission.

**Components**:
- `ClaudeCachedClient`: Wraps Anthropic SDK with `cache_control: ephemeral`
- `CacheMetricsLogger`: Tracks cache performance per KeaBotRun
- `FunctionRouter`: Routes function calls to handlers
- `KheaEventEmitter`: Broadcasts state changes across system

**Prompt Caching Strategy**:
Four cacheable context blocks (each <1,024 tokens):
1. **System prompt**: Role definition (DesignBot/EstimateBot/PermitBot)
2. **Pricing rules**: Imported from core-rules package
3. **Construction Task Catalog (CTC)**: 2026 DMV unit costs
4. **Execution constraints**: KeaBot chain rules, approval gates, model assignments

Cache hit on blocks 1-4 reduces input token cost by 90%.

**Target**: 40–60% API cost reduction via cache hits.

---

## Installation & Setup

### 1. Install Dependencies

```bash
npm install @anthropic-ai/sdk @prisma/client
```

### 2. Set Environment Variables

```bash
export ANTHROPIC_API_KEY="sk-ant-..."
export KEALEE_MODE="production"  # or "development"
export KEALEE_REGION="DMV"
```

### 3. Import Files

Copy to your Kealee Platform v20 project:
- `orgo-agent-structure.ts` → `packages/core-bots/src/orgo/`
- `hermes-function-routing.ts` → `packages/core-bots/src/hermes/`
- `obsidian-knowledge-base.ts` → `packages/core-bots/src/obsidian/`
- `kealee-integration-example.ts` → `packages/core-bots/src/integration/`

### 4. Initialize System

```typescript
import { KealeeAgentSystem } from "./kealee-integration-example";

const kealeeSystem = new KealeeAgentSystem();
export { kealeeSystem };
```

---

## Usage Patterns

### Pattern 1: AI Concept Only (DesignBot)

Input: 9-question intake answers
Output: Design concept + 3 concepts × 2 images each

```typescript
const result = await kealeeSystem.executeAIConcept(
  projectId,
  userId,
  {
    property_type: "Single-family home",
    scope: "HVAC upgrade",
    budget: "$45,000",
    timeline: "6 weeks",
    location: "Washington DC",
    square_footage: "2,800 SF",
    year_built: "1985",
    utilities: "Natural gas",
    code_compliance: "DC 14-1401",
  }
);

// Returns:
// {
//   status: "SUCCESS",
//   concept: {
//     conceptId: "concept-proj-001-...",
//     concept: "...",
//     assumptions: ["..."],
//     imagePrompts: ["...", "..."],
//     images: [...],
//     timeline: "6 weeks",
//     risks: ["..."]
//   }
// }
```

### Pattern 2: Estimate (DesignBot → EstimateBot)

Requires approved concept. DesignBot outputs become EstimateBot inputs.

```typescript
const result = await kealeeSystem.executeEstimate(
  projectId,
  userId,
  conceptId  // From previous concept result
);

// Returns:
// {
//   status: "SUCCESS",
//   concept: { ... },  // Re-used from prior stage
//   estimate: {
//     estimateId: "estimate-proj-001-...",
//     costs: {
//       hvac: { labor: 8000, materials: 12000, total: 20000 },
//       plumbing: { labor: 5000, materials: 6000, total: 11000 },
//       general: { labor: 2000, overhead: 3000, total: 5000 },
//       subtotal: 36000,
//       contingency: 5400,
//       builderRisk: 432,
//       total: 41832
//     },
//     breakdown: { ... },
//     timeline: { ... },
//     risks: [ ... ]
//   }
// }
```

### Pattern 3: Full Chain (DesignBot → EstimateBot → PermitBot)

Autonomous permit filing (DC DCRA or Maryland county).

```typescript
const result = await kealeeSystem.executePermitFiling(
  projectId,
  userId,
  conceptId,
  estimateId
);

// Returns:
// {
//   status: "SUCCESS",
//   concept: { ... },     // From stage 1
//   estimate: { ... },    // From stage 2
//   permit: {
//     permitId: "permit-proj-001-...",
//     jurisdiction: "DC_DCRA",
//     permitType: "REST_API",
//     documents: [ "plans.pdf", "pe-stamp.pdf", ... ],
//     filing: {
//       endpoint: "https://api.dcapps.dc.gov/permits/v2/submit",
//       payload: { ... },
//       status: "FILED"
//     },
//     verificationSteps: [
//       "Monitor permit status via API",
//       "Human verification of filing receipt",
//       "Log filing confirmation to Kealee Portal"
//     ]
//   }
// }
```

---

## Approval Workflows

Each chain stage has configurable approval gates:

### Concept Approval
- **Required role**: CLIENT
- **Auto-approve**: No (manual review required)
- **Timeout**: 48 hours

```typescript
// Check approval status
const approved = await obsidian.canProceedToNextStage(
  conceptId,
  "CONCEPT"
);

// Approve concept
await obsidian.approveConceptRecord(conceptId, "alice@client.com");
```

### Estimate Approval
- **Required roles**: CLIENT, FINANCE
- **Auto-approve**: No
- **Timeout**: 72 hours

### Permit Approval
- **Required roles**: PE, COMPLIANCE
- **Auto-approve**: Yes (after PE/Compliance sign-off)
- **Timeout**: 24 hours

---

## Prompt Caching Details

### How It Works

1. **First call** (cache miss):
   - All 4 context blocks sent to Claude
   - `cache_control: ephemeral` on final block
   - Input tokens: ~2,500 (system + rules + CTC + constraints)
   - Cache created: ~2,500 tokens (cost at 0.1x = 250 tokens)

2. **Second call** (cache hit):
   - Context blocks reused from cache
   - Blocks 1-4 read from cache in ~50ms
   - Input tokens: ~500 (only user prompt)
   - Cache read tokens: ~2,500 (cost at 0.01x = 25 tokens)
   - **Savings**: 225 tokens per call (~10% cost reduction for single project)
   - **Multi-project**: 40–60% reduction across portfolio

### Cache Metrics Example

```typescript
const metrics = await cacheLogger.getAggregateMetrics();

// Output:
// {
//   totalRequests: 15,
//   cacheHitRate: 0.73,  // 73% cache hit rate
//   avgCostSavingsPercent: 42.5,
//   totalTokensSaved: 18750
// }

// Interpretation:
// - 11 of 15 requests hit the cache
// - Average 42.5% cost reduction per request
// - Equivalent to ~2 free API calls worth of tokens saved
```

---

## Model Assignments (LOCKED)

**Cannot be changed without SESSION 12 smoke test passing:**

- **DesignBot**: Always Claude Opus 4.6
  - Justification: Complex creative output (3 design concepts, assumption synthesis)
  - Cost: ~$0.015/call (fully mitigated by cache hits)

- **EstimateBot**: Claude Sonnet 4.6 (or Sonnet 4-20250514 fallback)
  - Justification: Cost breakdown with regional adjustments, timeline analysis
  - Cost: ~$0.003/call (excellent speed/cost ratio)

- **PermitBot**: Claude Sonnet 4.6 (or Sonnet 4-20250514 fallback)
  - Justification: Autonomous permit filing, no creative output needed
  - Cost: ~$0.003/call

---

## Integration with Cursor/Next.js

### In Cursor IDE

1. Open `.mdc` configuration:
   ```bash
   cmd+k → "Create .mdc"
   ```

2. Add KeaBot context:
   ```markdown
   # Kealee Platform v20 - KeaBot Configuration
   
   ## Architecture
   - Three-layer: Orgo (org), Obsidian (KB), Hermes (routing)
   - DesignBot → EstimateBot → PermitBot (immutable chain)
   - Prompt caching on all Claude calls
   
   ## Key Files
   - `packages/core-bots/src/orgo/orgo-agent-structure.ts`
   - `packages/core-bots/src/hermes/hermes-function-routing.ts`
   - `packages/core-bots/src/obsidian/obsidian-knowledge-base.ts`
   
   ## Import Rules
   - NEVER hardcode pricing (always use Obsidian)
   - NEVER reference Zem Solutions
   - All KeaBot prompts require `cache_control: ephemeral`
   ```

3. Use inline assist:
   ```
   cmd+shift+a → "Implement EstimateBot handler following Hermes pattern"
   ```

### In Next.js API Route

```typescript
// app/api/concept/route.ts
import { kealeeSystem } from "@/packages/core-bots/src/integration/kealee-integration-example";

export async function POST(req: Request) {
  const { projectId, userId, intakeAnswers } = await req.json();
  
  try {
    const result = await kealeeSystem.executeAIConcept(
      projectId,
      userId,
      intakeAnswers
    );
    
    return Response.json(result);
  } catch (error) {
    return Response.json(
      { error: String(error) },
      { status: 500 }
    );
  }
}
```

---

## Event System

Listen for agent completion and errors:

```typescript
// When DesignBot completes
kealeeSystem.onEvent(KheaEvent.DESIGN_COMPLETE, (projectId, data) => {
  console.log(`Design ready for project ${projectId}`);
  // Trigger UI update, send notification, etc.
});

// When EstimateBot completes
kealeeSystem.onEvent(KheaEvent.ESTIMATE_COMPLETE, (projectId, data) => {
  console.log(`Estimate total: $${data.estimateId}`);
});

// When approval is required
kealeeSystem.onEvent(KheaEvent.APPROVAL_REQUIRED, (projectId, data) => {
  console.log(`Awaiting ${data.stage} approval for ${projectId}`);
  // Send Slack notification, create Jira task, etc.
});

// When error occurs
kealeeSystem.onEvent(KheaEvent.ERROR, (projectId, data) => {
  console.error(`Error in ${data.stage}: ${data.error}`);
  // Alert user, log to error tracking
});
```

---

## Pricing Rules: The Single Source of Truth

### Location
```
packages/core-rules/src/pricing.ts
```

### Structure
```typescript
// pricing.ts
export const pricingRules = {
  2026: {
    DMV: {
      baselineMultiplier: 1.28,  // +28%
      materialAdjustments: {
        lumber: 1.38,
        steel: 1.15,
        concrete: 1.08,
        electrical: 1.18,
      },
      hourlyRates: {
        HVAC: { base: 95, overhead: 1.35 },
        PLUMBING: { base: 110, overhead: 1.4 },
        ELECTRICAL: { base: 125, overhead: 1.45 },
        CARPENTRY: { base: 85, overhead: 1.3 },
        GENERAL_LABOR: { base: 65, overhead: 1.25 },
      },
      equipmentDailyRates: {
        CRANE: { min: 1200, max: 1800 },
        LIFT: { min: 400, max: 600 },
        COMPRESSOR: { min: 150, max: 250 },
      },
      contingencyRate: 0.15,
      builderRiskRate: 0.012,
    },
  },
};
```

### Usage in EstimateBot
```typescript
// ✅ Correct
const rules = await obsidian.getPricingRules("DMV", 2026);
const hvacRate = rules.hourlyRates.HVAC.regional;

// ❌ WRONG
const hvacRate = 121.60;  // Hardcoded

// ❌ WRONG
const hvacRate = { base: 95, overhead: 1.35 };  // Wrong structure
```

---

## Testing & Smoke Test (SESSION 12)

**Requirement**: All 12 smoke tests must pass before deployment.

```typescript
// tests/smoke-12-keabot.test.ts
describe("Kealee Agent Execution System", () => {
  let system: KealeeAgentSystem;
  
  beforeAll(() => {
    system = new KealeeAgentSystem();
  });

  test("1. DesignBot produces valid JSON output", async () => {
    const result = await system.executeAIConcept(
      "test-proj-1", "test-user", sampleIntake
    );
    expect(result.concept).toBeDefined();
    expect(result.concept.conceptId).toBeTruthy();
  });

  test("2. EstimateBot chains after concept", async () => {
    // Requires concept from test 1
  });

  test("3. PermitBot chains after estimate", async () => {
    // Requires estimate from test 2
  });

  test("4. Obsidian stores concept correctly", async () => {
    // Verify persistence
  });

  test("5. Pricing rules load from core-rules", async () => {
    const rules = await obsidian.getPricingRules();
    expect(rules.baselineMultiplier).toBe(1.28);
  });

  test("6. Cache metrics recorded", async () => {
    const metrics = await cacheLogger.getAggregateMetrics();
    expect(metrics.totalRequests).toBeGreaterThan(0);
  });

  test("7. Approval workflow blocks estimate", async () => {
    // Concept unapproved → estimate should wait
  });

  test("8. Events emit on completion", async () => {
    const emitted = [];
    system.onEvent(KheaEvent.DESIGN_COMPLETE, () => emitted.push(true));
    // Execute → verify event fired
  });

  test("9. DC DCRA permit blueprint matches DC API", async () => {
    const blueprint = await obsidian.getPermitBlueprint("DC_DCRA");
    expect(blueprint.type).toBe("REST_API");
    expect(blueprint.endpoint).toContain("dcapps.dc.gov");
  });

  test("10. Maryland Playwright automation fields correct", async () => {
    const blueprint = await obsidian.getPermitBlueprint("MARYLAND_MONTGOMERY");
    expect(blueprint.type).toBe("PLAYWRIGHT_AUTOMATION");
    expect(blueprint.formFields).toBeDefined();
  });

  test("11. No Zem Solutions references", async () => {
    // Scan all prompts for "Zem"
    expect(noZemReferences()).toBe(true);
  });

  test("12. Cache hit rate >= 40%", async () => {
    const metrics = await cacheLogger.getAggregateMetrics();
    expect(metrics.cacheHitRate).toBeGreaterThanOrEqual(0.4);
  });
});
```

---

## Troubleshooting

### Issue: Cache miss on repeated calls
**Cause**: Different user prompts prevent cache reuse.
**Solution**: Reuse `CacheableContext` across calls on same project.

```typescript
// Good
const ctx = createCacheableContext(projectId, ...);
await claudeClient.callClaudeWithCache(projectId, prompt1);
await claudeClient.callClaudeWithCache(projectId, prompt2);  // Cache hit

// Bad
await claudeClient.callClaudeWithCache(projectId1, prompt);
await claudeClient.callClaudeWithCache(projectId2, prompt);  // Cache miss
```

### Issue: EstimateBot can't find pricing
**Cause**: Obsidian not initialized or pricing.ts import broken.
**Solution**: 
```typescript
const rules = await obsidian.getPricingRules();
console.log(rules.baselineMultiplier);  // Should be 1.28
```

### Issue: PermitBot tries to file with unapproved estimate
**Cause**: Approval workflow not enforced.
**Solution**: 
```typescript
const canProceed = await obsidian.canProceedToNextStage(
  estimateId,
  "ESTIMATE"
);
if (!canProceed) throw new Error("Awaiting approval");
```

---

## Performance Metrics

**Baseline costs (no cache)**:
- DesignBot (Opus): ~$0.015
- EstimateBot (Sonnet): ~$0.003
- PermitBot (Sonnet): ~$0.003
- Total per chain: ~$0.021

**With cache hits (40-60%)**:
- First project: Full cost (~$0.021)
- Projects 2-5: ~$0.010 each (cache reuse)
- Average: ~$0.012 per chain (43% reduction)

**At scale (1,000 projects/month)**:
- Without cache: $21,000
- With cache: $12,000
- **Savings: $9,000/month (43%)**

---

## Next Steps

1. **Copy implementation files to your project**
2. **Run smoke tests (all 12 must pass)**
3. **Integrate into Next.js API routes**
4. **Deploy to Railway (services) and Vercel (portal apps)**
5. **Monitor cache metrics in production**
6. **Set up alerts for cache hit rate drop**

---

## Support & Questions

For implementation questions:
- Check existing KeaBot execution traces
- Review `packages/core-bots/src/` for similar patterns
- Consult Cursor IDE with `.mdc` configuration
- Run `pnpm test` to validate smoke tests

---

## Revision History

| Version | Date | Changes |
|---------|------|---------|
| 1.0 | 2026-05-16 | Initial implementation: Orgo, Obsidian, Hermes |

---

**Last Updated**: 2026-05-16
**Status**: READY FOR IMPLEMENTATION
**Deployment Gate**: SESSION 12 Smoke Test (All 12 checks must pass)
